# panels/__init__.py

from .rigging import VVTools_PT_Rigging

__all__ = [
    "VVTools_PT_Rigging",
]
