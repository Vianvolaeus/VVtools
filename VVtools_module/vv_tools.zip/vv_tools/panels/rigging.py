# panels/rigging.py

import bpy
from bpy.types import Panel

class VVTools_PT_Rigging(Panel):
    bl_idname = "VVTOOLS_PT_rigging"
    bl_label = "Rigging Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "VV Tools"

    def draw(self, context):
        layout = self.layout

        # Add the operators to the panel
        layout.operator("vv_tools.merge_to_active_bone", text="Merge Bones to Active")
        layout.operator("vv_tools.smooth_rig_xfer", text="Smooth Rig Transfer")
        # Add more operator buttons as needed

